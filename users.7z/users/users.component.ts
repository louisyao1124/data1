import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  fetchData = [{"title":"saurabh","description":"dd"},
  {"title":"aman","description":"dd"},
  {"title":"jessica","description":"dd"},
  {"title":"rosh","description":"dd"}]

  addRec(){
    //alert("aa");
    console.log("aa");
  }

  hey() {
    console.log("aa");
  }
  
  toggle() {
    console.log("aaa");
    //this.buttonValue = button.id;
    this.fetchData.push( {"title":"aa","description":"bb"} );
  }
  addOne() {
    console.log("aaa");
    //this.buttonValue = button.id;
    this.fetchData.push( {"title":"aa","description":"bb"} );
  }

  delOne() {
    console.log("aaa", this.fetchData.length);
    //this.buttonValue = button.id;
    this.fetchData.splice(this.fetchData.length-1, 1)
    //this.fetchData.push( {"title":"aa","description":"bb"} );
  }
  constructor() { }

  ngOnInit(): void {
  }

}
