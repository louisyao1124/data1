import 'jest-preset-angular';

import './jest-global-mocks'; // browser mocks globally available for every test