
**Angular version**:

**ng-multiselect-dropdown version**:

**Description of issue**:

**Steps to reproduce**:

**Expected result**:

**Actual result**:

**Demo**: Please share sample code link using StackBlitz or codesandbox

Any relevant code:
```

```