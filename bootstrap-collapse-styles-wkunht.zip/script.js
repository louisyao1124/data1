$(function() {
  $(".list-group-item").on("click", function() {
    let $target = $(event.target);
    $(".selected").toggleClass("selected");
    if ($target.children().length === 0) {
      $target.toggleClass("selected");
    }
    $(".bi", this)
      .toggleClass("bi-chevron-up")
      .toggleClass("bi-chevron-down");
  });
});
