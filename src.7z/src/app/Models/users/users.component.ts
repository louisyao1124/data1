import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

/*
  fetchData = [{"title":"saurabh1","description":"dd"},
  {"title":"aman2","description":"dd"},
  {"title":"jessica3","description":"dd"},
  {"title":"rosh4","description":"dd"},
  {"title":"jessica5","description":"dd"},
  {"title":"rosh6","description":"dd"}]
*/
  fetchData = [{"title":"saurabh","description":"dd"}]
  addStatus = false;
  addStatus1 = 0;

  addRec(){
    //alert("aa");
    console.log("aa");
  }

  hey() {
    console.log("aa");
  }
  
  toggle() {
    console.log("aaa");
    //this.buttonValue = button.id;
    this.fetchData.push( {"title":"aa","description":"bb"} );
  }
  addOne() {
    console.log("aaa");
    //this.buttonValue = button.id;
    this.fetchData.push( {"title":"aa","description":"bb"} );
  }

  delOne() {
    console.log("aaa", this.fetchData.length);
    //this.buttonValue = button.id;
    if(this.fetchData.length > 1){
      this.fetchData.splice(this.fetchData.length-1, 1)
      //this.fetchData.push( {"title":"aa","description":"bb"} );
    }

  }

  cancel() { 
    //alert("aa");
    this.fetchData.splice(1, this.fetchData.length-1);
 }

  constructor() { }

  ngOnInit(): void {
  }

}
